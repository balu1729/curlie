#!/bin/bash
# --- cd to $LOC.  
mkdir -p $LOC/scripts/hist
mkdir -p $LOC/scripts/u
mkdir -p $LOC/test
mkdir -p $LOC/conf
mkdir -p $LOC/arch
mkdir -p $LOC/arch/tmp
mkdir -p $LOC/locks
mkdir -p $LOC/pkg
mkdir -p $LOC/pkg/test
mkdir -p $LOC/pw
mkdir -p $LOC/tmp
mkdir -p $LOC/idata
mkdir -p $LOC/idata/arch
mkdir -p $LOC/idata/arch/tmp
mkdir -p $LOC/idata/tmp
