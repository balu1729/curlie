if [[ $SEL -eq 0 ]]
then
return
else
# --- setup selinux contexts for directories.
chcon -t httpd_sys_script_exec_t /etc/curlie/*
chcon -t httpd_sys_content_t $LOC/pw/*
chcon -t httpd_sys_content_rw_t $LOC/locks

/usr/sbin/setsebool -P httpd_can_network_connect on
/usr/sbin/setsebool -P httpd_enable_cgi on
fi


